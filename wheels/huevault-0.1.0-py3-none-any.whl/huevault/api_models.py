"""Serializable request and response models for CLI and JSON I/O."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .models import CanonicalColour, ColourFormat, ColourInput, RelationshipResult, SimilarityMode, SimilarityPolicy, SimilarityResult


@dataclass
class ColourInputRequest:
    input_id: str
    source_format: str
    source_values: list[float] | str
    source_id: str | None = None
    name: str | None = None
    source_profile: str | None = None
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_domain(self) -> ColourInput:
        return ColourInput(
            input_id=self.input_id,
            source_id=self.source_id,
            name=self.name,
            source_format=ColourFormat(self.source_format.lower()),
            source_values=self.source_values,
            source_profile=self.source_profile,
            provenance=dict(self.provenance),
        )


@dataclass
class SimilarityPolicyRequest:
    policy_id: str
    delta_e_threshold: float
    mode: str
    top_k: int | None = None
    description: str = ""

    def to_domain(self) -> SimilarityPolicy:
        return SimilarityPolicy(
            policy_id=self.policy_id,
            delta_e_threshold=self.delta_e_threshold,
            mode=SimilarityMode(self.mode),
            top_k=self.top_k,
            description=self.description,
        )


@dataclass
class CanonicalColourResponse:
    colour_id: str
    lab_l: float
    lab_a: float
    lab_b: float
    lch_l: float
    lch_c: float
    lch_h: float
    order_key: str
    status: str
    provenance: dict[str, Any]
    catalogue_id: str | None = None
    name: str | None = None
    collision_group_id: str | None = None
    collision_rank: int = 1
    collision_origin_catalogue_id: str | None = None
    is_collision_member: bool = False
    is_collision_origin: bool = False

    @classmethod
    def from_domain(cls, colour: CanonicalColour) -> "CanonicalColourResponse":
        return cls(**asdict(colour))


@dataclass
class SimilarityResultResponse:
    query_colour_id: str
    candidate_colour_id: str
    delta_e: float
    relationship_type: str
    rank: int
    candidate_catalogue_id: str | None = None

    @classmethod
    def from_domain(cls, result: SimilarityResult) -> "SimilarityResultResponse":
        return cls(**asdict(result))


@dataclass
class RelationshipResultResponse:
    query_colour_id: str
    candidate_colour_id: str
    relationship_type: str
    score: float | None = None
    candidate_catalogue_id: str | None = None

    @classmethod
    def from_domain(cls, result: RelationshipResult) -> "RelationshipResultResponse":
        return cls(**asdict(result))
