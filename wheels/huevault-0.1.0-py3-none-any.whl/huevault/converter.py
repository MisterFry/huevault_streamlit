"""Colour conversion utilities for canonical Lab and LCh handling."""

from __future__ import annotations

import math
from dataclasses import asdict

from .models import CanonicalColour, ColourFormat, ColourInput, QuantizationConfig


_D65_WHITE = (95.047, 100.0, 108.883)
_EPSILON = 216 / 24389
_KAPPA = 24389 / 27


class ColourConverter:
    """Converts supported input formats to canonical Lab and LCh."""

    @staticmethod
    def validate_input(colour_input: ColourInput) -> None:
        if colour_input.source_format is ColourFormat.LAB:
            if not isinstance(colour_input.source_values, list) or len(colour_input.source_values) != 3:
                raise ValueError("LAB input requires [L, a, b]")
            l_value, a_value, b_value = [float(value) for value in colour_input.source_values]
            if not 0.0 <= l_value <= 100.0:
                raise ValueError("LAB lightness must be within 0..100")
            if not all(-128.0 <= component <= 128.0 for component in (a_value, b_value)):
                raise ValueError("LAB a and b should be within -128..128")
            return

        if colour_input.source_format is ColourFormat.RGB:
            if not isinstance(colour_input.source_values, list) or len(colour_input.source_values) != 3:
                raise ValueError("RGB input requires [R, G, B]")
            if not all(0.0 <= float(channel) <= 255.0 for channel in colour_input.source_values):
                raise ValueError("RGB channels must be within 0..255")
            return

        if colour_input.source_format is ColourFormat.CMYK:
            if not isinstance(colour_input.source_values, list) or len(colour_input.source_values) != 4:
                raise ValueError("CMYK input requires [C, M, Y, K]")
            if not all(0.0 <= float(channel) <= 100.0 for channel in colour_input.source_values):
                raise ValueError("CMYK channels must be percentages within 0..100")
            return

        if colour_input.source_format is ColourFormat.HEX:
            if not isinstance(colour_input.source_values, str):
                raise ValueError("HEX input requires a string such as '#FF00AA'")
            ColourConverter.hex_to_rgb(colour_input.source_values)
            return

        raise ValueError(f"Unsupported colour format: {colour_input.source_format}")

    @staticmethod
    def hex_to_rgb(hex_value: str) -> tuple[float, float, float]:
        cleaned = hex_value.strip().lstrip("#")
        if len(cleaned) == 3:
            cleaned = "".join(character * 2 for character in cleaned)
        if len(cleaned) != 6 or any(character not in "0123456789abcdefABCDEF" for character in cleaned):
            raise ValueError("HEX input must be a 3-digit or 6-digit hexadecimal string")
        return tuple(float(int(cleaned[index : index + 2], 16)) for index in (0, 2, 4))

    @staticmethod
    def cmyk_to_rgb(cmyk: list[float]) -> tuple[float, float, float]:
        c_value, m_value, y_value, k_value = [float(channel) / 100.0 for channel in cmyk]
        red = 255.0 * (1.0 - c_value) * (1.0 - k_value)
        green = 255.0 * (1.0 - m_value) * (1.0 - k_value)
        blue = 255.0 * (1.0 - y_value) * (1.0 - k_value)
        return (red, green, blue)

    @staticmethod
    def rgb_to_xyz(rgb: tuple[float, float, float]) -> tuple[float, float, float]:
        def linearize(component: float) -> float:
            channel = component / 255.0
            if channel <= 0.04045:
                return channel / 12.92
            return ((channel + 0.055) / 1.055) ** 2.4

        red, green, blue = [linearize(component) for component in rgb]
        x_value = red * 0.4124564 + green * 0.3575761 + blue * 0.1804375
        y_value = red * 0.2126729 + green * 0.7151522 + blue * 0.0721750
        z_value = red * 0.0193339 + green * 0.1191920 + blue * 0.9503041
        return (x_value * 100.0, y_value * 100.0, z_value * 100.0)

    @staticmethod
    def xyz_to_lab(xyz: tuple[float, float, float]) -> tuple[float, float, float]:
        def pivot(value: float) -> float:
            if value > _EPSILON:
                return value ** (1.0 / 3.0)
            return (_KAPPA * value + 16.0) / 116.0

        x_value = pivot(xyz[0] / _D65_WHITE[0])
        y_value = pivot(xyz[1] / _D65_WHITE[1])
        z_value = pivot(xyz[2] / _D65_WHITE[2])
        return (max(0.0, 116.0 * y_value - 16.0), 500.0 * (x_value - y_value), 200.0 * (y_value - z_value))

    @staticmethod
    def lab_to_lch(lab: tuple[float, float, float]) -> tuple[float, float, float]:
        l_value, a_value, b_value = lab
        chroma = math.hypot(a_value, b_value)
        hue = math.degrees(math.atan2(b_value, a_value)) % 360.0
        return (l_value, chroma, hue)

    @staticmethod
    def lch_to_lab(lch: tuple[float, float, float]) -> tuple[float, float, float]:
        l_value, chroma, hue = lch
        radians = math.radians(hue)
        return (l_value, chroma * math.cos(radians), chroma * math.sin(radians))

    @staticmethod
    def convert_to_lab(colour_input: ColourInput) -> tuple[float, float, float]:
        ColourConverter.validate_input(colour_input)
        if colour_input.source_format is ColourFormat.LAB:
            l_value, a_value, b_value = [float(value) for value in colour_input.source_values]  # type: ignore[arg-type]
            return (l_value, a_value, b_value)
        if colour_input.source_format is ColourFormat.RGB:
            rgb = tuple(float(value) for value in colour_input.source_values)  # type: ignore[arg-type]
            return ColourConverter.xyz_to_lab(ColourConverter.rgb_to_xyz(rgb))
        if colour_input.source_format is ColourFormat.HEX:
            rgb = ColourConverter.hex_to_rgb(str(colour_input.source_values))
            return ColourConverter.xyz_to_lab(ColourConverter.rgb_to_xyz(rgb))
        if colour_input.source_format is ColourFormat.CMYK:
            rgb = ColourConverter.cmyk_to_rgb([float(value) for value in colour_input.source_values])  # type: ignore[arg-type]
            return ColourConverter.xyz_to_lab(ColourConverter.rgb_to_xyz(rgb))
        raise ValueError(f"Unsupported colour format: {colour_input.source_format}")

    @staticmethod
    def generate_colour_id(lch: tuple[float, float, float], quantization: QuantizationConfig | None = None) -> str:
        quantization = quantization or QuantizationConfig()
        quantization.validate()
        l_value, chroma, hue = lch
        hue_bin = int(round(hue / quantization.hue_step_degrees) * quantization.hue_step_degrees) % 360
        l_bin = int(round(l_value * quantization.lightness_scale))
        c_bin = int(round(chroma * quantization.chroma_scale))
        return f"{hue_bin:03d}.{l_bin:03d}.{c_bin:03d}"

    @staticmethod
    def generate_order_key(lch: tuple[float, float, float]) -> str:
        l_value, chroma, hue = lch
        return f"{hue:06.2f}:{l_value:06.2f}:{chroma:06.2f}"

    @staticmethod
    def canonicalize(colour_input: ColourInput, quantization: QuantizationConfig | None = None) -> CanonicalColour:
        quantization = quantization or QuantizationConfig()
        lab = ColourConverter.convert_to_lab(colour_input)
        lch = ColourConverter.lab_to_lch(lab)
        provenance = colour_input.normalized_provenance()
        provenance["canonicalization"] = {
            "lab": [round(component, 6) for component in lab],
            "lch": [round(component, 6) for component in lch],
            "quantization": asdict(quantization),
        }
        return CanonicalColour(
            colour_id=ColourConverter.generate_colour_id(lch, quantization),
            lab_l=float(lab[0]),
            lab_a=float(lab[1]),
            lab_b=float(lab[2]),
            lch_l=float(lch[0]),
            lch_c=float(lch[1]),
            lch_h=float(lch[2]),
            order_key=ColourConverter.generate_order_key(lch),
            provenance=provenance,
            name=colour_input.name,
        )
