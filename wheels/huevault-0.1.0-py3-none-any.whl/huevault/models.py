"""Domain models for the colour registry."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ColourFormat(str, Enum):
    LAB = "lab"
    RGB = "rgb"
    HEX = "hex"
    CMYK = "cmyk"


class SimilarityMode(str, Enum):
    THRESHOLD = "threshold"
    TOP_K = "top_k"
    COMBINED = "combined"


class DeduplicationMode(str, Enum):
    STRICT_MERGE = "strict_merge"
    ALLOW_DUPLICATES = "allow_duplicates"
    FLAG_ONLY = "flag_only"


class CollisionMode(str, Enum):
    ALLOW = "allow"
    SUFFIX = "suffix"
    REJECT = "reject"


@dataclass(frozen=True)
class QuantizationConfig:
    hue_step_degrees: int = 1
    lightness_scale: int = 2
    chroma_scale: int = 2

    def validate(self) -> None:
        if self.hue_step_degrees <= 0 or 360 % self.hue_step_degrees != 0:
            raise ValueError("hue_step_degrees must be a positive divisor of 360")
        if self.lightness_scale <= 0:
            raise ValueError("lightness_scale must be positive")
        if self.chroma_scale <= 0:
            raise ValueError("chroma_scale must be positive")


@dataclass(frozen=True)
class RelationshipConfig:
    complementary_tolerance: float = 10.0
    analogous_tolerance: float = 30.0
    require_lightness_similarity: bool = False
    require_chroma_similarity: bool = False
    lightness_tolerance: float = 10.0
    chroma_tolerance: float = 15.0


@dataclass(frozen=True)
class RuntimeConfig:
    quantization: QuantizationConfig = field(default_factory=QuantizationConfig)
    deduplication_mode: DeduplicationMode = DeduplicationMode.FLAG_ONLY
    collision_mode: CollisionMode = CollisionMode.ALLOW
    relationships: RelationshipConfig = field(default_factory=RelationshipConfig)


@dataclass
class ColourInput:
    input_id: str
    source_format: ColourFormat
    source_values: list[float] | str
    source_id: str | None = None
    name: str | None = None
    source_profile: str | None = None
    provenance: dict[str, Any] = field(default_factory=dict)

    def normalized_provenance(self) -> dict[str, Any]:
        payload = dict(self.provenance)
        payload.setdefault("input_id", self.input_id)
        if self.source_id is not None:
            payload.setdefault("source_id", self.source_id)
        if self.name is not None:
            payload.setdefault("name", self.name)
        if self.source_profile is not None:
            payload.setdefault("source_profile", self.source_profile)
        payload.setdefault("source_format", self.source_format.value)
        return payload


@dataclass
class CanonicalColour:
    colour_id: str
    lab_l: float
    lab_a: float
    lab_b: float
    lch_l: float
    lch_c: float
    lch_h: float
    order_key: str
    status: str = "active"
    provenance: dict[str, Any] = field(default_factory=dict)
    catalogue_id: str | None = None
    name: str | None = None
    collision_group_id: str | None = None
    collision_rank: int = 1
    collision_origin_catalogue_id: str | None = None
    is_collision_member: bool = False
    is_collision_origin: bool = False

    @property
    def lab(self) -> tuple[float, float, float]:
        return (self.lab_l, self.lab_a, self.lab_b)

    @property
    def lch(self) -> tuple[float, float, float]:
        return (self.lch_l, self.lch_c, self.lch_h)


@dataclass(frozen=True)
class SimilarityPolicy:
    policy_id: str
    delta_e_threshold: float
    mode: SimilarityMode
    top_k: int | None = None
    description: str = ""

    def validate(self) -> None:
        if self.delta_e_threshold < 0:
            raise ValueError("delta_e_threshold must be non-negative")
        if self.mode in (SimilarityMode.TOP_K, SimilarityMode.COMBINED):
            if self.top_k is None or self.top_k <= 0:
                raise ValueError("top_k must be a positive integer for top_k and combined modes")
        if self.mode is SimilarityMode.THRESHOLD and self.top_k is not None and self.top_k <= 0:
            raise ValueError("top_k must be positive when provided")


@dataclass
class SimilarityResult:
    query_colour_id: str
    candidate_colour_id: str
    delta_e: float
    relationship_type: str
    rank: int
    candidate_catalogue_id: str | None = None


@dataclass
class RelationshipResult:
    query_colour_id: str
    candidate_colour_id: str
    relationship_type: str
    score: float | None = None
    candidate_catalogue_id: str | None = None


def builtin_similarity_policies() -> dict[str, SimilarityPolicy]:
    return {
        "exact": SimilarityPolicy("exact", 0.5, SimilarityMode.THRESHOLD, description="Indistinguishable colours"),
        "close": SimilarityPolicy("close", 2.0, SimilarityMode.THRESHOLD, description="Very similar colours"),
        "similar": SimilarityPolicy("similar", 5.0, SimilarityMode.THRESHOLD, description="Visually similar colours"),
    }
