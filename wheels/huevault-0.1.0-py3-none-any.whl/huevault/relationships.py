"""Structural colour-space relationships."""

from __future__ import annotations

from .models import CanonicalColour, RelationshipConfig, RelationshipResult


class RelationshipEngine:
    """Compute hue-geometry relationships in LCh space."""

    def __init__(self, config: RelationshipConfig | None = None):
        self.config = config or RelationshipConfig()

    def find_relationships(
        self,
        query_colour: CanonicalColour,
        relationship_type: str,
        candidates: list[CanonicalColour],
    ) -> list[RelationshipResult]:
        relationship = relationship_type.lower()
        if relationship not in {"complementary", "analogous"}:
            raise ValueError(f"Unsupported relationship type: {relationship_type}")

        results: list[RelationshipResult] = []
        for candidate in candidates:
            if candidate.catalogue_id == query_colour.catalogue_id:
                continue
            score = self._score(query_colour, candidate, relationship)
            if score is None:
                continue
            results.append(
                RelationshipResult(
                    query_colour_id=query_colour.colour_id,
                    candidate_colour_id=candidate.colour_id,
                    relationship_type=relationship,
                    score=score,
                    candidate_catalogue_id=candidate.catalogue_id,
                )
            )

        results.sort(
            key=lambda item: (
                -(item.score if item.score is not None else -1.0),
                item.candidate_colour_id,
                item.candidate_catalogue_id or "",
            )
        )
        return results

    def _score(self, query: CanonicalColour, candidate: CanonicalColour, relationship: str) -> float | None:
        hue_distance = self._hue_difference(query.lch_h, candidate.lch_h)
        if relationship == "complementary":
            deviation = abs(hue_distance - 180.0)
            if deviation > self.config.complementary_tolerance:
                return None
            tolerance = self.config.complementary_tolerance
        else:
            deviation = hue_distance
            if deviation > self.config.analogous_tolerance:
                return None
            tolerance = self.config.analogous_tolerance

        if self.config.require_lightness_similarity and abs(query.lch_l - candidate.lch_l) > self.config.lightness_tolerance:
            return None
        if self.config.require_chroma_similarity and abs(query.lch_c - candidate.lch_c) > self.config.chroma_tolerance:
            return None

        base_score = max(0.0, 1.0 - (deviation / tolerance if tolerance else 1.0))
        return round(base_score, 6)

    @staticmethod
    def _hue_difference(left: float, right: float) -> float:
        distance = abs((left - right) % 360.0)
        return min(distance, 360.0 - distance)
