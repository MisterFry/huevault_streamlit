"""Perceptual similarity search using CIEDE2000."""

from __future__ import annotations

import math

from .models import CanonicalColour, SimilarityMode, SimilarityPolicy, SimilarityResult


class SimilarityEngine:
    """Compute perceptual distances and policy-driven similarity matches."""

    @staticmethod
    def delta_e_ciede2000(left: CanonicalColour, right: CanonicalColour) -> float:
        l1, a1, b1 = left.lab
        l2, a2, b2 = right.lab

        c1 = math.hypot(a1, b1)
        c2 = math.hypot(a2, b2)
        c_bar = (c1 + c2) / 2.0
        g_value = 0.5 * (1.0 - math.sqrt((c_bar**7) / (c_bar**7 + 25.0**7))) if c_bar != 0 else 0.0

        a1_prime = (1.0 + g_value) * a1
        a2_prime = (1.0 + g_value) * a2
        c1_prime = math.hypot(a1_prime, b1)
        c2_prime = math.hypot(a2_prime, b2)

        h1_prime = SimilarityEngine._hue_angle(a1_prime, b1)
        h2_prime = SimilarityEngine._hue_angle(a2_prime, b2)

        delta_l_prime = l2 - l1
        delta_c_prime = c2_prime - c1_prime
        delta_h_prime = SimilarityEngine._delta_h_prime(c1_prime, c2_prime, h1_prime, h2_prime)
        delta_h_term = 2.0 * math.sqrt(c1_prime * c2_prime) * math.sin(math.radians(delta_h_prime) / 2.0)

        l_bar_prime = (l1 + l2) / 2.0
        c_bar_prime = (c1_prime + c2_prime) / 2.0
        h_bar_prime = SimilarityEngine._mean_h_prime(c1_prime, c2_prime, h1_prime, h2_prime)

        t_value = (
            1.0
            - 0.17 * math.cos(math.radians(h_bar_prime - 30.0))
            + 0.24 * math.cos(math.radians(2.0 * h_bar_prime))
            + 0.32 * math.cos(math.radians(3.0 * h_bar_prime + 6.0))
            - 0.20 * math.cos(math.radians(4.0 * h_bar_prime - 63.0))
        )
        delta_theta = 30.0 * math.exp(-(((h_bar_prime - 275.0) / 25.0) ** 2))
        r_c = 2.0 * math.sqrt((c_bar_prime**7) / (c_bar_prime**7 + 25.0**7)) if c_bar_prime != 0 else 0.0
        s_l = 1.0 + (0.015 * ((l_bar_prime - 50.0) ** 2)) / math.sqrt(20.0 + ((l_bar_prime - 50.0) ** 2))
        s_c = 1.0 + 0.045 * c_bar_prime
        s_h = 1.0 + 0.015 * c_bar_prime * t_value
        r_t = -math.sin(math.radians(2.0 * delta_theta)) * r_c

        return float(
            math.sqrt(
                (delta_l_prime / s_l) ** 2
                + (delta_c_prime / s_c) ** 2
                + (delta_h_term / s_h) ** 2
                + r_t * (delta_c_prime / s_c) * (delta_h_term / s_h)
            )
        )

    @staticmethod
    def classify(delta_e: float) -> str:
        if delta_e <= 0.5:
            return "exact"
        if delta_e <= 2.0:
            return "close"
        if delta_e <= 5.0:
            return "similar"
        return "outside"

    def search(
        self,
        query_colour: CanonicalColour,
        candidates: list[CanonicalColour],
        policy: SimilarityPolicy,
    ) -> list[SimilarityResult]:
        policy.validate()
        results: list[SimilarityResult] = []
        for candidate in candidates:
            if candidate.catalogue_id == query_colour.catalogue_id:
                continue
            delta_e = self.delta_e_ciede2000(query_colour, candidate)
            results.append(
                SimilarityResult(
                    query_colour_id=query_colour.colour_id,
                    candidate_colour_id=candidate.colour_id,
                    delta_e=delta_e,
                    relationship_type=self.classify(delta_e),
                    rank=0,
                    candidate_catalogue_id=candidate.catalogue_id,
                )
            )

        results.sort(key=lambda item: (round(item.delta_e, 12), item.candidate_colour_id, item.candidate_catalogue_id or ""))

        if policy.mode is SimilarityMode.THRESHOLD:
            filtered = [result for result in results if result.delta_e <= policy.delta_e_threshold]
        elif policy.mode is SimilarityMode.TOP_K:
            filtered = results[: policy.top_k or len(results)]
        elif policy.mode is SimilarityMode.COMBINED:
            in_threshold = [result for result in results if result.delta_e <= policy.delta_e_threshold]
            filtered = in_threshold[: policy.top_k or len(in_threshold)]
        else:
            raise ValueError(f"Unsupported similarity mode: {policy.mode}")

        for index, result in enumerate(filtered, start=1):
            result.rank = index
        return filtered

    @staticmethod
    def _hue_angle(a_value: float, b_value: float) -> float:
        if a_value == 0.0 and b_value == 0.0:
            return 0.0
        return math.degrees(math.atan2(b_value, a_value)) % 360.0

    @staticmethod
    def _delta_h_prime(c1_prime: float, c2_prime: float, h1_prime: float, h2_prime: float) -> float:
        if c1_prime == 0.0 or c2_prime == 0.0:
            return 0.0
        delta = h2_prime - h1_prime
        if abs(delta) <= 180.0:
            return delta
        if delta > 180.0:
            return delta - 360.0
        return delta + 360.0

    @staticmethod
    def _mean_h_prime(c1_prime: float, c2_prime: float, h1_prime: float, h2_prime: float) -> float:
        if c1_prime == 0.0 or c2_prime == 0.0:
            return h1_prime + h2_prime
        if abs(h1_prime - h2_prime) <= 180.0:
            return (h1_prime + h2_prime) / 2.0
        if (h1_prime + h2_prime) < 360.0:
            return (h1_prime + h2_prime + 360.0) / 2.0
        return (h1_prime + h2_prime - 360.0) / 2.0
