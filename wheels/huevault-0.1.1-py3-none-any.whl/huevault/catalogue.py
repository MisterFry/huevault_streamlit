"""SQLite-backed catalogue storage."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .models import CanonicalColour, CollisionMode, ColourInput, DeduplicationMode, RuntimeConfig, SimilarityMode, SimilarityPolicy


class ColourCatalogue:
    """Persistent storage for canonical colours and policies."""

    def __init__(self, db_path: str = "huevault.db"):
        self.db_path = str(Path(db_path))
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path)
        connection.row_factory = sqlite3.Row
        return connection

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS colours (
                    row_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    catalogue_id TEXT NOT NULL UNIQUE,
                    colour_id TEXT NOT NULL,
                    name TEXT,
                    lab_l REAL NOT NULL,
                    lab_a REAL NOT NULL,
                    lab_b REAL NOT NULL,
                    lch_l REAL NOT NULL,
                    lch_c REAL NOT NULL,
                    lch_h REAL NOT NULL,
                    order_key TEXT NOT NULL,
                    status TEXT NOT NULL,
                    source_format TEXT NOT NULL,
                    source_values TEXT NOT NULL,
                    source_id TEXT,
                    input_id TEXT NOT NULL,
                    source_profile TEXT,
                    provenance TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_colours_colour_id ON colours(colour_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_colours_order_key ON colours(order_key)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_colours_lab ON colours(lab_l, lab_a, lab_b)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_colours_lch ON colours(lch_l, lch_c, lch_h)")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS similarity_policies (
                    policy_id TEXT PRIMARY KEY,
                    delta_e_threshold REAL NOT NULL,
                    mode TEXT NOT NULL,
                    top_k INTEGER,
                    description TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS transformation_log (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    input_id TEXT NOT NULL,
                    colour_id TEXT NOT NULL,
                    catalogue_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.commit()

    def upsert_policy(self, policy: SimilarityPolicy) -> None:
        policy.validate()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO similarity_policies (policy_id, delta_e_threshold, mode, top_k, description)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(policy_id)
                DO UPDATE SET
                    delta_e_threshold = excluded.delta_e_threshold,
                    mode = excluded.mode,
                    top_k = excluded.top_k,
                    description = excluded.description
                """,
                (policy.policy_id, policy.delta_e_threshold, policy.mode.value, policy.top_k, policy.description),
            )
            conn.commit()

    def get_policy(self, policy_id: str) -> SimilarityPolicy | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT policy_id, delta_e_threshold, mode, top_k, description FROM similarity_policies WHERE policy_id = ?",
                (policy_id,),
            ).fetchone()
        if row is None:
            return None
        return SimilarityPolicy(
            policy_id=row["policy_id"],
            delta_e_threshold=float(row["delta_e_threshold"]),
            mode=SimilarityMode(row["mode"]),
            top_k=row["top_k"],
            description=row["description"],
        )

    def store_colour(self, colour: CanonicalColour, colour_input: ColourInput, runtime_config: RuntimeConfig) -> CanonicalColour:
        existing = self.find_by_colour_id(colour.colour_id)
        identical = next((item for item in existing if self._same_lab(item, colour)), None)

        if identical is not None and runtime_config.deduplication_mode is DeduplicationMode.STRICT_MERGE:
            self._log_transformation(
                colour_input.input_id,
                identical.colour_id,
                identical.catalogue_id or identical.colour_id,
                "strict_merge",
                {"reason": "Identical canonical colour already existed"},
            )
            return identical

        if identical is not None and runtime_config.deduplication_mode is DeduplicationMode.FLAG_ONLY:
            colour.status = "duplicate"

        collision = any(not self._same_lab(item, colour) for item in existing)
        if collision and runtime_config.collision_mode is CollisionMode.REJECT:
            raise ValueError(f"Deterministic colour ID collision for {colour.colour_id}")

        colour.catalogue_id = self._allocate_catalogue_id(colour.colour_id, runtime_config.collision_mode)

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO colours (
                    catalogue_id, colour_id, name, lab_l, lab_a, lab_b, lch_l, lch_c, lch_h, order_key,
                    status, source_format, source_values, source_id, input_id, source_profile, provenance, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    colour.catalogue_id,
                    colour.colour_id,
                    colour.name,
                    colour.lab_l,
                    colour.lab_a,
                    colour.lab_b,
                    colour.lch_l,
                    colour.lch_c,
                    colour.lch_h,
                    colour.order_key,
                    colour.status,
                    colour_input.source_format.value,
                    json.dumps(colour_input.source_values),
                    colour_input.source_id,
                    colour_input.input_id,
                    colour_input.source_profile,
                    json.dumps(colour.provenance, sort_keys=True),
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
            conn.commit()

        self._log_transformation(
            input_id=colour_input.input_id,
            colour_id=colour.colour_id,
            catalogue_id=colour.catalogue_id,
            event_type="ingest",
            payload={
                "source_format": colour_input.source_format.value,
                "source_values": colour_input.source_values,
                "status": colour.status,
                "catalogue_id": colour.catalogue_id,
            },
        )
        return colour

    def get_by_catalogue_id(self, catalogue_id: str) -> CanonicalColour | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM colours WHERE catalogue_id = ?", (catalogue_id,)).fetchone()
        return self._row_to_colour(row) if row else None

    def find_by_colour_id(self, colour_id: str) -> list[CanonicalColour]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM colours WHERE colour_id = ? ORDER BY order_key, catalogue_id",
                (colour_id,),
            ).fetchall()
        return [self._row_to_colour(row) for row in rows]

    def get_colour(self, identifier: str) -> CanonicalColour:
        by_catalogue = self.get_by_catalogue_id(identifier)
        if by_catalogue is not None:
            return by_catalogue
        matches = self.find_by_colour_id(identifier)
        if not matches:
            raise ValueError(f"Colour '{identifier}' not found")
        if len(matches) > 1:
            catalogue_ids = ", ".join(item.catalogue_id or item.colour_id for item in matches)
            raise ValueError(f"Identifier '{identifier}' is ambiguous; use one of: {catalogue_ids}")
        return matches[0]

    def get_all_colours(self, include_inactive: bool = False) -> list[CanonicalColour]:
        query = "SELECT * FROM colours"
        if not include_inactive:
            query += " WHERE status != 'inactive'"
        query += " ORDER BY order_key, catalogue_id"
        with self._connect() as conn:
            rows = conn.execute(query).fetchall()
        return [self._row_to_colour(row) for row in rows]

    def find_by_lab(self, lab: tuple[float, float, float], tolerance: float = 0.0) -> list[CanonicalColour]:
        return [
            colour
            for colour in self.get_all_colours()
            if abs(colour.lab_l - lab[0]) <= tolerance
            and abs(colour.lab_a - lab[1]) <= tolerance
            and abs(colour.lab_b - lab[2]) <= tolerance
        ]

    def find_by_lch(self, lch: tuple[float, float, float], tolerance: float = 0.0) -> list[CanonicalColour]:
        return [
            colour
            for colour in self.get_all_colours()
            if abs(colour.lch_l - lch[0]) <= tolerance
            and abs(colour.lch_c - lch[1]) <= tolerance
            and self._hue_difference(colour.lch_h, lch[2]) <= tolerance
        ]

    def count_colours(self) -> int:
        with self._connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS colour_count FROM colours WHERE status != 'inactive'").fetchone()
        return int(row["colour_count"])

    def get_transformation_log(self) -> list[dict[str, object]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM transformation_log ORDER BY log_id").fetchall()
        return [dict(row) for row in rows]

    def _allocate_catalogue_id(self, colour_id: str, collision_mode: CollisionMode) -> str:
        with self._connect() as conn:
            existing_ids = {
                row["catalogue_id"]
                for row in conn.execute(
                    "SELECT catalogue_id FROM colours WHERE colour_id = ? OR catalogue_id LIKE ?",
                    (colour_id, f"{colour_id}-%"),
                ).fetchall()
            }
        if colour_id not in existing_ids:
            return colour_id
        if collision_mode is CollisionMode.ALLOW:
            return f"entry-{self._next_row_id()}"
        if collision_mode is CollisionMode.SUFFIX:
            index = 2
            while f"{colour_id}-{index}" in existing_ids:
                index += 1
            return f"{colour_id}-{index}"
        return colour_id

    def _next_row_id(self) -> int:
        with self._connect() as conn:
            row = conn.execute("SELECT COALESCE(MAX(row_id), 0) + 1 AS next_row_id FROM colours").fetchone()
        return int(row["next_row_id"])

    def _log_transformation(
        self,
        input_id: str,
        colour_id: str,
        catalogue_id: str,
        event_type: str,
        payload: dict[str, object],
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO transformation_log (input_id, colour_id, catalogue_id, event_type, payload, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    input_id,
                    colour_id,
                    catalogue_id,
                    event_type,
                    json.dumps(payload, sort_keys=True),
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
            conn.commit()

    @staticmethod
    def _same_lab(left: CanonicalColour, right: CanonicalColour, epsilon: float = 1e-9) -> bool:
        return (
            abs(left.lab_l - right.lab_l) <= epsilon
            and abs(left.lab_a - right.lab_a) <= epsilon
            and abs(left.lab_b - right.lab_b) <= epsilon
        )

    @staticmethod
    def _row_to_colour(row: sqlite3.Row) -> CanonicalColour:
        return CanonicalColour(
            colour_id=row["colour_id"],
            lab_l=float(row["lab_l"]),
            lab_a=float(row["lab_a"]),
            lab_b=float(row["lab_b"]),
            lch_l=float(row["lch_l"]),
            lch_c=float(row["lch_c"]),
            lch_h=float(row["lch_h"]),
            order_key=row["order_key"],
            status=row["status"],
            provenance=json.loads(row["provenance"]),
            catalogue_id=row["catalogue_id"],
            name=row["name"],
        )

    @staticmethod
    def _hue_difference(left: float, right: float) -> float:
        distance = abs((left - right) % 360.0)
        return min(distance, 360.0 - distance)
