"""Command-line interface for the colour registry."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict

from .models import CollisionMode, DeduplicationMode, RelationshipConfig, SimilarityMode, SimilarityPolicy
from .service import HueVaultService, build_runtime_config


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="colour", description="Colour Registry & Similarity Service")
    parser.add_argument("--db", default="huevault.db", help="SQLite catalogue path")
    parser.add_argument("--hue-step", type=int, default=1, help="Quantization step for hue in degrees")
    parser.add_argument("--lightness-scale", type=int, default=2, help="Quantization multiplier for L*")
    parser.add_argument("--chroma-scale", type=int, default=2, help="Quantization multiplier for C*")
    parser.add_argument(
        "--deduplication-mode",
        choices=[mode.value for mode in DeduplicationMode],
        default=DeduplicationMode.STRICT_MERGE.value,
        help="Duplicate handling during ingestion",
    )
    parser.add_argument(
        "--collision-mode",
        choices=[mode.value for mode in CollisionMode],
        default=CollisionMode.REJECT.value,
        help="Collision handling for colours sharing a deterministic ID",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    load_parser = subparsers.add_parser("load", help="Ingest colours from a JSON or CSV file")
    load_parser.add_argument("input_file", help="Path to input JSON or CSV")

    match_parser = subparsers.add_parser("match", help="Find colours within a policy or threshold")
    match_parser.add_argument("--id", required=True, dest="identifier", help="Deterministic colour ID or unique catalogue ID")
    match_parser.add_argument("--policy", default="close", help="Policy ID to use")
    match_parser.add_argument("--threshold", type=float, help="Override the policy threshold")
    match_parser.add_argument("--top", type=int, help="Optional top-k limit")
    match_parser.add_argument("--mode", choices=[mode.value for mode in SimilarityMode], help="Override the policy mode")

    nearest_parser = subparsers.add_parser("nearest", help="Return nearest colours")
    nearest_parser.add_argument("--id", required=True, dest="identifier", help="Deterministic colour ID or unique catalogue ID")
    nearest_parser.add_argument("--top", type=int, default=10, help="Number of results to return")
    nearest_parser.add_argument("--threshold", type=float, help="Optional maximum delta E")

    relate_parser = subparsers.add_parser("relate", help="Find structural colour relationships")
    relate_parser.add_argument("--id", required=True, dest="identifier", help="Deterministic colour ID or unique catalogue ID")
    relate_parser.add_argument("--type", required=True, dest="relationship_type", choices=["complementary", "analogous"])
    relate_parser.add_argument("--tolerance", type=float, help="Hue tolerance override")
    relate_parser.add_argument("--require-lightness", action="store_true", help="Require similar lightness")
    relate_parser.add_argument("--require-chroma", action="store_true", help="Require similar chroma")
    relate_parser.add_argument("--lightness-tolerance", type=float, default=10.0)
    relate_parser.add_argument("--chroma-tolerance", type=float, default=15.0)

    policy_parser = subparsers.add_parser("policy", help="Create or update a similarity policy")
    policy_parser.add_argument("--policy-id", required=True)
    policy_parser.add_argument("--threshold", required=True, type=float)
    policy_parser.add_argument("--mode", required=True, choices=[mode.value for mode in SimilarityMode])
    policy_parser.add_argument("--top", type=int)
    policy_parser.add_argument("--description", default="")

    show_parser = subparsers.add_parser("show", help="Show a stored colour")
    show_parser.add_argument("--id", required=True, dest="identifier")

    lookup_parser = subparsers.add_parser("lookup", help="Find colours by Lab or LCh coordinates")
    lookup_group = lookup_parser.add_mutually_exclusive_group(required=True)
    lookup_group.add_argument("--lab", nargs=3, type=float, metavar=("L", "A", "B"))
    lookup_group.add_argument("--lch", nargs=3, type=float, metavar=("L", "C", "H"))
    lookup_parser.add_argument("--tolerance", type=float, default=0.0, help="Per-component lookup tolerance")

    subparsers.add_parser("stats", help="Show catalogue statistics")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    service = HueVaultService(
        db_path=args.db,
        runtime_config=build_runtime_config(
            hue_step_degrees=args.hue_step,
            lightness_scale=args.lightness_scale,
            chroma_scale=args.chroma_scale,
            deduplication_mode=args.deduplication_mode,
            collision_mode=args.collision_mode,
        ),
    )

    if args.command == "load":
        _print_json([asdict(colour) for colour in service.load_from_file(args.input_file)])
        return 0

    if args.command == "match":
        mode = SimilarityMode(args.mode) if args.mode else None
        results = service.find_similar(
            args.identifier,
            policy_id=args.policy,
            delta_e_threshold=args.threshold,
            top_k=args.top,
            mode=mode,
        )
        _print_json([asdict(result) for result in results])
        return 0

    if args.command == "nearest":
        mode = SimilarityMode.COMBINED if args.threshold is not None else SimilarityMode.TOP_K
        policy = SimilarityPolicy(
            policy_id="cli_nearest",
            delta_e_threshold=args.threshold if args.threshold is not None else float("inf"),
            mode=mode,
            top_k=args.top,
            description="Nearest colours from CLI",
        )
        _print_json([asdict(result) for result in service.find_similar(args.identifier, policy=policy)])
        return 0

    if args.command == "relate":
        relationship_config = RelationshipConfig(
            complementary_tolerance=args.tolerance if args.relationship_type == "complementary" and args.tolerance is not None else 10.0,
            analogous_tolerance=args.tolerance if args.relationship_type == "analogous" and args.tolerance is not None else 30.0,
            require_lightness_similarity=args.require_lightness,
            require_chroma_similarity=args.require_chroma,
            lightness_tolerance=args.lightness_tolerance,
            chroma_tolerance=args.chroma_tolerance,
        )
        _print_json(
            [
                asdict(result)
                for result in service.find_relationships(
                    args.identifier,
                    args.relationship_type,
                    relationship_config=relationship_config,
                )
            ]
        )
        return 0

    if args.command == "policy":
        policy = SimilarityPolicy(
            policy_id=args.policy_id,
            delta_e_threshold=args.threshold,
            mode=SimilarityMode(args.mode),
            top_k=args.top,
            description=args.description,
        )
        service.register_policy(policy)
        _print_json(asdict(policy))
        return 0

    if args.command == "show":
        _print_json(asdict(service.get_colour(args.identifier)))
        return 0

    if args.command == "lookup":
        if args.lab is not None:
            _print_json([asdict(colour) for colour in service.find_by_lab(tuple(args.lab), tolerance=args.tolerance)])
            return 0
        _print_json([asdict(colour) for colour in service.find_by_lch(tuple(args.lch), tolerance=args.tolerance)])
        return 0

    if args.command == "stats":
        _print_json(service.get_catalogue_stats())
        return 0

    parser.error(f"Unknown command: {args.command}")
    return 2


def _print_json(payload: object) -> None:
    print(json.dumps(payload, indent=2, sort_keys=True))
