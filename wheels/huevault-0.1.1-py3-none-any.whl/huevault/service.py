"""Main service orchestration for the colour registry."""

from __future__ import annotations

import csv
import json
import logging
from dataclasses import replace
from pathlib import Path
from typing import Any

from .catalogue import ColourCatalogue
from .converter import ColourConverter
from .models import (
    CanonicalColour,
    CollisionMode,
    ColourFormat,
    ColourInput,
    DeduplicationMode,
    QuantizationConfig,
    RelationshipConfig,
    RelationshipResult,
    RuntimeConfig,
    SimilarityMode,
    SimilarityPolicy,
    SimilarityResult,
    builtin_similarity_policies,
)
from .relationships import RelationshipEngine
from .similarity import SimilarityEngine


class HueVaultService:
    """Facade for ingestion, storage, similarity search, and relationships."""

    def __init__(self, db_path: str = "huevault.db", runtime_config: RuntimeConfig | None = None):
        self.runtime_config = runtime_config or RuntimeConfig()
        self.catalogue = ColourCatalogue(db_path)
        self.similarity_engine = SimilarityEngine()
        self.relationship_engine = RelationshipEngine(self.runtime_config.relationships)
        self.logger = logging.getLogger(__name__)
        self._ensure_builtin_policies()

    def _ensure_builtin_policies(self) -> None:
        for policy in builtin_similarity_policies().values():
            self.catalogue.upsert_policy(policy)

    def register_policy(self, policy: SimilarityPolicy) -> SimilarityPolicy:
        policy.validate()
        self.catalogue.upsert_policy(policy)
        return policy

    def get_policy(self, policy_id: str) -> SimilarityPolicy:
        policy = self.catalogue.get_policy(policy_id)
        if policy is None:
            raise ValueError(f"Policy '{policy_id}' not found")
        return policy

    def ingest_colour(self, colour_input: ColourInput) -> CanonicalColour:
        self.logger.info("Ingesting colour %s", colour_input.input_id)
        canonical = ColourConverter.canonicalize(colour_input, self.runtime_config.quantization)
        stored = self.catalogue.store_colour(canonical, colour_input, self.runtime_config)
        self.logger.info("Stored colour %s as %s", stored.colour_id, stored.catalogue_id)
        return stored

    def ingest_colours(self, colour_inputs: list[ColourInput]) -> list[CanonicalColour]:
        return [self.ingest_colour(colour_input) for colour_input in colour_inputs]

    def load_from_json(self, file_path: str) -> list[CanonicalColour]:
        payload = json.loads(Path(file_path).read_text(encoding="utf-8-sig"))
        if isinstance(payload, dict):
            colours_payload = payload.get("colours") or payload.get("palette") or []
        else:
            colours_payload = payload
        if not isinstance(colours_payload, list):
            raise ValueError("JSON input must be a list or contain a 'colours' list")
        return self.ingest_colours([self._colour_input_from_mapping(item) for item in colours_payload])

    def load_from_csv(self, file_path: str) -> list[CanonicalColour]:
        with Path(file_path).open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
        return self.ingest_colours([self._colour_input_from_mapping(row) for row in rows])

    def load_from_file(self, file_path: str) -> list[CanonicalColour]:
        suffix = Path(file_path).suffix.lower()
        if suffix == ".json":
            return self.load_from_json(file_path)
        if suffix == ".csv":
            return self.load_from_csv(file_path)
        raise ValueError("Only .json and .csv files are supported")

    def get_colour(self, identifier: str) -> CanonicalColour:
        return self.catalogue.get_colour(identifier)

    def find_by_lab(self, lab: tuple[float, float, float], tolerance: float = 0.0) -> list[CanonicalColour]:
        return self.catalogue.find_by_lab(lab, tolerance=tolerance)

    def find_by_lch(self, lch: tuple[float, float, float], tolerance: float = 0.0) -> list[CanonicalColour]:
        return self.catalogue.find_by_lch(lch, tolerance=tolerance)

    def find_similar(
        self,
        identifier: str,
        policy: SimilarityPolicy | None = None,
        *,
        policy_id: str | None = None,
        delta_e_threshold: float | None = None,
        top_k: int | None = None,
        mode: SimilarityMode | None = None,
    ) -> list[SimilarityResult]:
        if policy is None and policy_id is None:
            raise ValueError("Similarity queries require an explicit policy or policy_id")
        query_colour = self.get_colour(identifier)
        active_policy = self._resolve_policy(policy, policy_id, delta_e_threshold, top_k, mode)
        return self.similarity_engine.search(query_colour, self.catalogue.get_all_colours(), active_policy)

    def find_relationships(
        self,
        identifier: str,
        relationship_type: str,
        *,
        relationship_config: RelationshipConfig | None = None,
    ) -> list[RelationshipResult]:
        query_colour = self.get_colour(identifier)
        if relationship_config is not None:
            engine = RelationshipEngine(relationship_config)
            return engine.find_relationships(query_colour, relationship_type, self.catalogue.get_all_colours())
        return self.relationship_engine.find_relationships(query_colour, relationship_type, self.catalogue.get_all_colours())

    def get_catalogue_stats(self) -> dict[str, Any]:
        return {
            "total_colours": self.catalogue.count_colours(),
            "policies": self.list_policies(),
            "transformations_logged": len(self.catalogue.get_transformation_log()),
        }

    def list_policies(self) -> list[str]:
        with self.catalogue._connect() as conn:
            rows = conn.execute("SELECT policy_id FROM similarity_policies ORDER BY policy_id").fetchall()
        return [row["policy_id"] for row in rows]

    def _resolve_policy(
        self,
        policy: SimilarityPolicy | None,
        policy_id: str | None,
        delta_e_threshold: float | None,
        top_k: int | None,
        mode: SimilarityMode | None,
    ) -> SimilarityPolicy:
        if policy is not None:
            selected = policy
        elif policy_id is not None:
            selected = self.get_policy(policy_id)
        else:
            raise ValueError("Similarity queries require an explicit policy or policy_id")

        if delta_e_threshold is None and top_k is None and mode is None:
            return selected

        selected = replace(
            selected,
            delta_e_threshold=delta_e_threshold if delta_e_threshold is not None else selected.delta_e_threshold,
            top_k=top_k if top_k is not None else selected.top_k,
            mode=mode if mode is not None else selected.mode,
        )
        selected.validate()
        return selected

    @staticmethod
    def _colour_input_from_mapping(item: dict[str, Any]) -> ColourInput:
        source_format = ColourFormat(str(item["source_format"]).lower())
        source_values = item["source_values"]
        if isinstance(source_values, str) and source_format is not ColourFormat.HEX:
            source_values = json.loads(source_values)
        elif isinstance(source_values, str) and source_format is ColourFormat.HEX:
            source_values = source_values.strip()
        return ColourInput(
            input_id=str(item["input_id"]),
            source_id=item.get("source_id"),
            name=item.get("name"),
            source_format=source_format,
            source_values=source_values,
            source_profile=item.get("source_profile"),
            provenance=_parse_provenance(item.get("provenance")),
        )


def _parse_provenance(value: Any) -> dict[str, Any]:
    if value is None or value == "":
        return {}
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, str):
        return json.loads(value)
    raise ValueError("provenance must be either a JSON object or a JSON string")


def build_runtime_config(
    *,
    hue_step_degrees: int = 1,
    lightness_scale: int = 2,
    chroma_scale: int = 2,
    deduplication_mode: str = DeduplicationMode.STRICT_MERGE.value,
    collision_mode: str = CollisionMode.REJECT.value,
) -> RuntimeConfig:
    return RuntimeConfig(
        quantization=QuantizationConfig(
            hue_step_degrees=hue_step_degrees,
            lightness_scale=lightness_scale,
            chroma_scale=chroma_scale,
        ),
        deduplication_mode=DeduplicationMode(deduplication_mode),
        collision_mode=CollisionMode(collision_mode),
    )
